import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Scanner;

public class Client {

    private String server_name;
    private int server_port;

    public Client(String server, int port) throws IOException {
        server_name = server;
        server_port = port;
    }

    public Client(String server) throws IOException {
        server_name = server;
        server_port = 13;
    }

    public void sendMessage(String message) throws IOException {

        InputStream stream;
        String answer = "";
        String fragment;
        int n;


        Socket client_socket = new Socket();

        if(message.equals("Quit")){
            client_socket.shutdownOutput();
            client_socket.close();
        }
        byte[] buffer = new byte[1024];
        InetSocketAddress server_address = new InetSocketAddress(server_name, server_port);
        client_socket.connect(server_address);
        stream = client_socket.getInputStream();
        OutputStreamWriter msg_out = new OutputStreamWriter(client_socket.getOutputStream());
        msg_out.write(message);
        msg_out.flush();

        while ((n = stream.read(buffer)) != -1) {
            fragment = new String(buffer, 0, n);
            answer = answer + fragment;
        }


    }

    public static void main(String args[]) {
        String server;
        int port;
        String send;
        Client client;
        Client client2;

        if (args.length != 3) {
            server = "127.0.0.1"; // localhost
            port = 13; // porta TCP standard servizio daytime
        } else {
            server = args[0];
            port = Integer.parseInt(args[1]);
        }
        try {
            client = new Client(server, port);
            Scanner scanner = new Scanner(System.in);
            String input = "";
            client2 = new Client(server,port);

            /*
            while (true) {
                input = scanner.next();
                client.sendMessage(input);
            }
             */
            int i=0;
            while(i<5) {
                i++;
                client.sendMessage("Ciao");

            }
            client2.sendMessage("Exit");


        } catch (SocketTimeoutException exception) {
            System.err.println("Nessuna risposta dal server!");
        } catch (IOException exception) {
            System.err.println("Client disconnesso");
        }
    }

}
