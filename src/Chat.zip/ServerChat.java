import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class ServerChat extends Thread {

    private ServerSocket server;

    public ServerChat(int port) throws IOException {
        server = new ServerSocket(port);

    }

    public ServerChat() throws IOException {
        server = new ServerSocket(13);
    }

    public void run() {
        Socket connection = null;

        char[] buffer = new char[1024];

        while (!Thread.interrupted()) {
            try {
                connection = server.accept();
                System.out.println("Messaggio ricevuto da: " +
                        connection.getInetAddress().toString() + ":" + connection.getPort());

                InputStreamReader received_msg = new InputStreamReader(connection.getInputStream());

                int lenght = received_msg.read(buffer, 0, buffer.length);
                String msg = new String(buffer, 0, lenght);
                System.out.println( msg );

                if (msg.equals("Exit")) {
                    connection.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SocketException e){
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        int c;

        try {
            ServerChat daytime_server = new ServerChat();
            daytime_server.start();
            c = System.in.read();
            daytime_server.interrupt();
            daytime_server.join();
        } catch (IOException exception) {
            System.err.println("Errore!");
        } catch (InterruptedException exception) {
            System.err.println("Errore!");
        }
    }
}
